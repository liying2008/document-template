#!/usr/bin/python
# -*- coding: utf-8 -*-

from .template import DocumentTemplate

__author__ = 'liying'

__all__ = ['DocumentTemplate']
